var text_box = '<div class="card-panel right" style="width: 75%; position: relative">' +
        '<div style="position: absolute; top: 0; left:3px; font-weight: bolder" class="title">{sender}</div>' +
        '{message}' +'<button onclick="decoded(this.id)" id="{zzz}" style="display:inline; width:50px; height:50px; border-radius:25px; background-color:#00ACE9; font-size:20px; color:black;">'+'{decode}'+'</button></div>';
var image_box= '<input type="text" value="{image_mess}">';

function scrolltoend() {
    $('#board').stop().animate({
        scrollTop: $('#board')[0].scrollHeight
    }, 800);
}

function decoded(iden){
    m="/static/second/"+iden;
    // m=document.getElementById('identity').src;
    // m=$('#images').attr('src');
    console.log(m)
    $.ajax({
        url:'/decoded',
        type:'post', 
        data: { message:m,
                csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()
            },
        dataType:'text',
        success:function(data)
            {
            alert(data);
            var image_boxes=image_box.replace('{image_mess}',data);
            $('#board').append(image_boxes);
            console.log(data)
        }
    });
}

function send(sender, receiver, message) {
    $.post('/api/messages', '{"sender": "'+ sender +'", "receiver": "'+ receiver +'","message": "'+ message +'" }', function (data) {
        console.log(data);
        source="/static/second/"+message
        var ext = message.split('.').pop();
        var box = text_box.replace('{sender}', "You");
        '{% load staticfiles %}'
    if(ext === "jpg" || ext==="jpeg" || ext==="png") 
    {
     var box= box.replace('{message}','<img id="{images_id}" width=300px height=300px src="source" />');
     var box=box.replace('{decode}','D');
     var box=box.replace('source',source);
     var box=box.replace('{zzz}',message);
     var box=box.replace('{images_id}',source);
     $('#board').append(box);
    }
    else
    {
    console.log("Yes")
     var  box = box.replace('{message}', message);
     var box= box.replace('inline','none');
     $('#board').append(box);
        
    }
    // var aSound = document.createElement('audio');
    // aSound.setAttribute('src','/static/beep.wav');
    // aSound.play();
        // $('#board').append(box);

        scrolltoend();
    })
}

function receive() {
    $.get('/api/messages/'+ sender_id + '/' + receiver_id, function (data) {
        console.log(data);
        console.log("OK");
        if (data.length !== 0)
        {
            for(var i=0;i<data.length;i++) {
                console.log(data[i]);
                var ext = data[i].message.split('.').pop();
                var box = text_box.replace('{sender}', data[i].sender);
                 '{% load staticfiles %}'
                if( ext !== "jpg" || ext!=="jpeg" || ext!=="png") 
                {
                    var box = box.replace('{message}', data[i].message);
                  var box= box.replace('inline','none'); 
                   
                }
                else
                {
                source= "/static/second/"+data[i].message
                 var box= box.replace('{message}','<img id="{images_id}" width=300px height=300px src="source" />');
                 var box= box.replace('{decode}','D');
                 var box= box.replace('{zzz}',data[i].message);
                 var box=box.replace('{images_id}',source);
                 var box= box.replace('source',source);
                }
                box = box.replace('right', 'left blue lighten-5');
                $('#board').append(box);
                var aSound = document.createElement('audio');
                aSound.setAttribute('src','/static/beep.wav');
                aSound.play();
                scrolltoend();
            }
        }
    })
}

function register(username, password) {
    $.post('/api/users', '{"username": "'+ username +'", "password": "'+ password +'"}',
        function (data) {
        console.log(data);
        window.location = '/';
        }).fail(function (response) {
            $('#id_username').addClass('invalid');
        })
}