from django.contrib.auth.views import logout
from django.urls import path
from django.conf.urls import url
from . import views


urlpatterns = [
    # path('',views.final,name='final'),
    path('', views.index, name='index'),
    path('chat', views.chat_view, name='chats'),
    path('chat/<int:sender>/<int:receiver>', views.message_view, name='chat'),
    path('api/messages/<int:sender>/<int:receiver>', views.message_list, name='message-detail'),
    path('api/messages', views.message_list, name='message-list'),
    path('api/users/<int:pk>', views.user_list, name='user-detail'),
    path('api/users', views.user_list, name='user-list'),
    path('logout', logout, {'next_page': 'index'}, name='logout'),
    path('register', views.register_view, name='register'),
    path('encode',views.encode,name='encode'),
    path('decoded',views.decoded,name='decoded'),
    path('addimage',views.addimage,name='addimage'),
    # path('delete',views.deletemessage,name='deletemessage'),
]
